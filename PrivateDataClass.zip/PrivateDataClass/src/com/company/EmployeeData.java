package com.company;

public class EmployeeData {
    private String name;
    private String department;
    private Integer numberOfYears;
    private Integer age;
    private Double salary;

    public String getName() {
        return name;
    }

    public String getDepartment() {
        return department;
    }

    public Integer getNumberOfYears() {
        return numberOfYears;
    }

    public Integer getAge() {
        return age;
    }

    public Double getSalary() {
        return salary;
    }

    public EmployeeData(String name, String department, Integer numberOfYears, Integer age, Double salary){
        this.name = name;
        this.age = age;
        this.department = department;
        this.numberOfYears = numberOfYears;
        this.salary = salary;
    }
}
