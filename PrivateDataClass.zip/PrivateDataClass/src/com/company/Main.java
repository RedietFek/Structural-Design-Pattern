package com.company;

public class Main {

    public static void main(String[] args) {
	Employee employee = new Employee("John Doe", "Marketing", 5, 41, 12000.0);
        System.out.println("monthly salary:"+employee.monthlySalary().toString());
        System.out.println("yearly salary:"+employee.yearlySalary().toString());
    }
}
