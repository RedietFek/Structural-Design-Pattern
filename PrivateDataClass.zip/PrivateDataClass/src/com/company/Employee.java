package com.company;

public class Employee {
    private EmployeeData employeeData;

    public Employee(String name, String department, Integer numberOfYears, Integer age, Double salary) {
        this.employeeData =new EmployeeData(name, department, numberOfYears, age, salary);
    }
    public Double monthlySalary(){
        return employeeData.getSalary() - employeeData.getSalary() * 10.0/100.0;
    }
    public Double yearlySalary(){
        return 12.0 * monthlySalary();
    }
}
