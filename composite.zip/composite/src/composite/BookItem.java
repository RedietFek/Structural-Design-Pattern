
package composite;

public class BookItem extends BookComponent {
    String name;
    
    public BookItem(String name){
        this.name=name;
    }
 
    public String getname(){
        return name;
    }
    
    public void print(){
        System.out.print("      --> " + getname()+ "\n");
    }
    
}
