
package composite;

public class Client {
    BookComponent allBooks;
    
    public Client (BookComponent allBooks){
        this.allBooks=allBooks;
    }    
    public void printBook(){
        allBooks.print();
    }
}
