
package composite;

public class Test {

    public static void main(String[] args) {
        BookComponent allBooks= new Subject("BOOKS IN STORE");
         
        Subject fiction= new Subject("    FICTION");
        Subject poetry= new Subject("    POETRY");
        Subject biography= new Subject("    BIOGRAPHY");
        Subject biography1= new Subject("       -ETHINIC AND CULTURE");
        Subject biography2= new Subject("       -LEADER AND NOBLE MAN");
        
        
        allBooks.add(fiction);
        allBooks.add(poetry);
        allBooks.add(biography);
        biography.add(biography1); 
        biography.add(biography2); 
        
        fiction.add(new BookItem("fkreske mekabr"));  
        fiction.add(new BookItem("dertogada"));
        fiction.add(new BookItem("keadmas bashager"));
        poetry.add(new BookItem("yegtm medbel"));
        poetry.add(new BookItem("fetena"));
        biography1.add(new BookItem("yewanka guzo"));
        biography1.add(new BookItem("yeamhara ena oromo yezer taric"));
        biography2.add(new BookItem("atse Minilic"));
        biography2.add(new BookItem("Teferri Mekonnen"));

    Client client= new Client(allBooks);
    client.printBook();
    
    }
    
}
