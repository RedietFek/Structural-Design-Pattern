
package composite;

import java.util.ArrayList;
import java.util.Iterator;

public class Subject extends BookComponent {
    ArrayList bookComponents= new ArrayList(); 
   String name;
   
   public Subject(String name){
       this.name=name;
   }
   public void add(BookComponent bookComponent){
       bookComponents.add(bookComponent);
   }
   public void remove(BookComponent bookComponent){
       bookComponents.add(bookComponent);
   }
   
   public String getName(){
       return name;
   }
    
   public void print(){
       System.out.print("\n" + "  " + getName());
       System.out.println("\n"+ "------------------------------------");
       
       Iterator iterator= bookComponents.iterator();
       while (iterator.hasNext()){
           BookComponent bookComponent=(BookComponent)iterator.next();
           bookComponent.print();
        }      
   }
}
